"""
AWS Cloud Portal V7
- AES-256-GCM encryption for all data
- S3 as primary storage for encrypted records
- Multi-tenant isolation
- Live security metrics
- Python 3.9+ compatible (no | None type hints)
"""
import os
import time
import traceback
from datetime import datetime, timezone, timedelta
from functools import wraps

import jwt as pyjwt
from flask import Flask, request, jsonify, render_template, g
from werkzeug.security import generate_password_hash, check_password_hash

from database import get_db, init_schema
from encryption import encrypt, decrypt, is_encrypted
import s3_storage as s3

# ── App setup ─────────────────────────────────────────────────────
app = Flask(__name__)

JWT_SECRET  = os.environ.get('JWT_SECRET', 'change-this-secret-in-production-v7')
JWT_EXPIRES = 3600  # 1 hour

# ── Global error handlers ─────────────────────────────────────────
@app.errorhandler(500)
def err_500(e):
    traceback.print_exc()
    return jsonify({'error': 'Server error: ' + str(e)}), 500

@app.errorhandler(404)
def err_404(e):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(Exception)
def err_any(e):
    traceback.print_exc()
    return jsonify({'error': 'Unexpected error: ' + str(e)}), 500

# ── AWS EC2 ───────────────────────────────────────────────────────
AWS_ENABLED = False
_ec2        = None
_region     = os.environ.get('AWS_REGION', 'ap-south-1')

try:
    import boto3
    _k = os.environ.get('AWS_ACCESS_KEY_ID', '')
    _s = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    if _k and _s:
        _ec2 = boto3.client('ec2', region_name=_region,
                            aws_access_key_id=_k, aws_secret_access_key=_s)
        _ec2.describe_regions(RegionNames=[_region])
        AWS_ENABLED = True
        print("[EC2] Connected — " + _region)
    else:
        print("[EC2] No keys set — simulation mode")
except Exception as e:
    print("[EC2] " + str(e))

# ── DB helpers ────────────────────────────────────────────────────
def db():
    if 'db' not in g:
        g.db = get_db()
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    d = g.pop('db', None)
    if d:
        d.close()

# ── Request timer ─────────────────────────────────────────────────
@app.before_request
def start_timer():
    g._t0 = time.time()

def elapsed_ms():
    return int((time.time() - getattr(g, '_t0', time.time())) * 1000)

# ── JWT helpers ───────────────────────────────────────────────────
def make_token(payload):
    d = dict(payload)
    d['exp'] = datetime.now(timezone.utc) + timedelta(seconds=JWT_EXPIRES)
    return pyjwt.encode(d, JWT_SECRET, algorithm='HS256')

def jwt_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get('Authorization', '')
        if not auth.startswith('Bearer '):
            return jsonify({'error': 'Missing token — please login'}), 401
        try:
            g.jwt_payload = pyjwt.decode(
                auth.split(' ', 1)[1], JWT_SECRET, algorithms=['HS256'])
        except pyjwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expired — please login again'}), 401
        except Exception:
            return jsonify({'error': 'Invalid token'}), 401
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if g.jwt_payload.get('role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return wrapper

# ── User helpers ──────────────────────────────────────────────────
def current_user():
    uid = g.jwt_payload['user_id']
    return db().execute(
        "SELECT u.*, i.name AS instance_name "
        "FROM users u LEFT JOIN instances i ON i.id = u.instance_id "
        "WHERE u.id = ?", (uid,)
    ).fetchone()

def is_superadmin(u):
    return u['role'] == 'admin' and u['instance_id'] is None

def is_admin(u):
    return u['role'] == 'admin'

def row_to_dict(row):
    """Safely convert sqlite3.Row to JSON-serializable dict."""
    result = {}
    for key in row.keys():
        val = row[key]
        if isinstance(val, (str, int, float, bool, type(None))):
            result[key] = val
        else:
            result[key] = str(val)
    return result

# ── Logging ───────────────────────────────────────────────────────
def log_action(action, status, user_id=None, username=None,
               instance_id=None, details=None):
    try:
        ms = elapsed_ms()
        c  = get_db()
        c.execute(
            "INSERT INTO activity_logs "
            "(action, status, user_id, username, instance_id, ip_address, response_ms, details) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (action, status, user_id, username, instance_id,
             request.remote_addr, ms, details)
        )
        c.commit()
        c.close()
    except Exception:
        pass

# ── AWS EC2 helpers ───────────────────────────────────────────────
def aws_launch(name, itype='t2.micro'):
    if not AWS_ENABLED:
        sim_id = 'i-sim-' + name.lower().replace(' ', '')[:12]
        return sim_id, 'Simulation', None
    try:
        r    = _ec2.run_instances(
            ImageId='ami-0f5ee92e2d63afc18', InstanceType=itype,
            MinCount=1, MaxCount=1,
            TagSpecifications=[{
                'ResourceType': 'instance',
                'Tags': [{'Key': 'Name', 'Value': name}]
            }]
        )
        inst = r['Instances'][0]
        return inst['InstanceId'], inst.get('PublicIpAddress', 'Pending'), None
    except Exception as e:
        return None, None, str(e)

def aws_stop(aws_id):
    if not AWS_ENABLED or (aws_id and aws_id.startswith('i-sim')):
        return
    try:
        _ec2.stop_instances(InstanceIds=[aws_id])
    except Exception:
        pass

def aws_terminate(aws_id):
    if not AWS_ENABLED or (aws_id and aws_id.startswith('i-sim')):
        return
    try:
        _ec2.terminate_instances(InstanceIds=[aws_id])
    except Exception:
        pass

def aws_sync():
    if not AWS_ENABLED:
        return [], "AWS not connected"
    try:
        resp  = _ec2.describe_instances()
        found = []
        conn  = get_db()
        for res in resp['Reservations']:
            for inst in res['Instances']:
                if inst['State']['Name'] == 'terminated':
                    continue
                aws_id = inst['InstanceId']
                ip     = inst.get('PublicIpAddress') or inst.get('PrivateIpAddress') or 'N/A'
                itype  = inst.get('InstanceType', 't2.micro')
                state  = inst['State']['Name']
                name   = aws_id
                for t in inst.get('Tags', []):
                    if t['Key'] == 'Name' and t['Value'].strip():
                        name = t['Value'].strip()
                        break
                ex = conn.execute(
                    "SELECT id FROM instances WHERE aws_id = ?", (aws_id,)
                ).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE instances SET status = ?, ip_address = ? WHERE aws_id = ?",
                        (state, ip, aws_id)
                    )
                    conn.commit()
                    found.append({'aws_id': aws_id, 'name': name, 'status': 'updated'})
                else:
                    base = name
                    c2   = 1
                    while conn.execute(
                        "SELECT id FROM instances WHERE name = ?", (name,)
                    ).fetchone():
                        name = base + '-' + str(c2)
                        c2  += 1
                    cur = conn.execute(
                        "INSERT INTO instances (name, aws_id, region, status, ip_address, plan, source) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?)",
                        (name, aws_id, _region, state, ip, itype, 'aws')
                    )
                    conn.commit()
                    iid     = cur.lastrowid
                    adm     = name.lower().replace(' ', '_') + '_admin'
                    mail    = adm + '@awsinstance.com'
                    pwd     = 'Admin@1234'
                    try:
                        conn.execute(
                            "INSERT INTO users (username, email, password_hash, plain_password, role, instance_id) "
                            "VALUES (?, ?, ?, ?, ?, ?)",
                            (adm, mail, generate_password_hash(pwd), pwd, 'admin', iid)
                        )
                        conn.commit()
                    except Exception:
                        pass
                    found.append({
                        'aws_id': aws_id, 'name': name,
                        'status': 'imported',
                        'admin_username': adm, 'admin_password': pwd
                    })
        conn.close()
        return found, None
    except Exception as e:
        return [], str(e)

# ── Pages ─────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/admin')
def admin_panel():
    return render_template('admin.html')

# ── Auth ──────────────────────────────────────────────────────────
@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json() or {}
        uname = data.get('username', '').strip()
        pwd   = data.get('password', '')
        if not uname or not pwd:
            return jsonify({'error': 'Username and password required'}), 400
        row = db().execute(
            "SELECT * FROM users WHERE username = ?", (uname,)
        ).fetchone()
        if not row or not check_password_hash(row['password_hash'], pwd):
            log_action('LOGIN', 'FAILED', details=uname)
            return jsonify({'error': 'Invalid username or password'}), 401
        if not row['is_active']:
            return jsonify({'error': 'Account is disabled'}), 403
        inst = None
        if row['instance_id']:
            inst = db().execute(
                "SELECT * FROM instances WHERE id = ?", (row['instance_id'],)
            ).fetchone()
        token = make_token({
            'user_id':     row['id'],
            'instance_id': row['instance_id'],
            'role':        row['role'],
        })
        log_action('LOGIN', 'SUCCESS',
                   user_id=row['id'], username=row['username'],
                   instance_id=row['instance_id'])
        return jsonify({
            'access_token': token,
            'user': {
                'id':           row['id'],
                'username':     row['username'],
                'email':        row['email'],
                'role':         row['role'],
                'instance_id':  row['instance_id'],
                'instance_name': inst['name'] if inst else None,
                'is_superadmin': row['instance_id'] is None and row['role'] == 'admin',
            }
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': 'Login error: ' + str(e)}), 500

@app.route('/api/me')
@jwt_required
def me():
    u = current_user()
    if not u:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({
        'id':           u['id'],
        'username':     u['username'],
        'email':        u['email'],
        'role':         u['role'],
        'instance_id':  u['instance_id'],
        'instance_name': u['instance_name'],
        'is_superadmin': is_superadmin(u),
    })

# ── AWS ───────────────────────────────────────────────────────────
@app.route('/api/aws/status')
@jwt_required
def aws_status():
    info = s3.get_status()
    info['aws_enabled'] = AWS_ENABLED
    info['region']      = _region
    return jsonify(info)

@app.route('/api/aws/sync', methods=['POST'])
@jwt_required
@admin_required
def sync_aws():
    found, err = aws_sync()
    if err:
        return jsonify({'error': err}), 500
    return jsonify({
        'message':     'Sync done — ' + str(len(found)) + ' instances',
        'instances':   found,
        'aws_enabled': AWS_ENABLED,
    })

# ── Instances ─────────────────────────────────────────────────────
@app.route('/api/instances', methods=['GET'])
@jwt_required
def get_instances():
    u = current_user()
    if is_superadmin(u):
        rows = db().execute(
            "SELECT * FROM instances ORDER BY created_at DESC"
        ).fetchall()
    else:
        rows = db().execute(
            "SELECT * FROM instances WHERE id = ?", (u['instance_id'],)
        ).fetchall()
    result = []
    for r in rows:
        rec = row_to_dict(r)
        rec['user_count'] = db().execute(
            "SELECT COUNT(*) FROM users WHERE instance_id = ?", (r['id'],)
        ).fetchone()[0]
        rec['data_count'] = db().execute(
            "SELECT COUNT(*) FROM instance_data WHERE instance_id = ?", (r['id'],)
        ).fetchone()[0]
        result.append(rec)
    return jsonify({'instances': result, 'aws_enabled': AWS_ENABLED})

@app.route('/api/instances', methods=['POST'])
@jwt_required
@admin_required
def create_instance():
    try:
        u    = current_user()
        data = request.get_json() or {}
        name = data.get('name', '').strip()
        if not name:
            return jsonify({'error': 'Instance name required'}), 400
        if db().execute(
            "SELECT id FROM instances WHERE name = ?", (name,)
        ).fetchone():
            return jsonify({'error': 'Instance name already exists'}), 409
        plan            = data.get('plan', 't2.micro')
        aws_id, ip, err = aws_launch(name, plan)
        if err:
            return jsonify({'error': 'AWS Error: ' + err}), 500
        region = _region if AWS_ENABLED else 'local'
        cur    = db().execute(
            "INSERT INTO instances (name, aws_id, region, status, ip_address, plan, source) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (name, aws_id, region, 'running', ip, plan, 'portal')
        )
        db().commit()
        iid      = cur.lastrowid
        adm_user = data.get('admin_username', name.lower().replace(' ', '_') + '_admin')
        adm_mail = data.get('admin_email',    adm_user + '@portal.com')
        adm_pass = data.get('admin_password', 'Admin@1234')
        try:
            db().execute(
                "INSERT INTO users (username, email, password_hash, plain_password, role, instance_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (adm_user, adm_mail, generate_password_hash(adm_pass), adm_pass, 'admin', iid)
            )
            db().commit()
        except Exception:
            pass
        log_action('CREATE_INSTANCE', 'SUCCESS',
                   user_id=u['id'], username=u['username'],
                   instance_id=iid, details=name + '|' + str(aws_id))
        return jsonify({
            'message':        'Instance created',
            'instance_id':    iid,
            'aws_id':         aws_id,
            'ip':             ip,
            'aws_enabled':    AWS_ENABLED,
            'admin_username': adm_user,
            'admin_password': adm_pass,
        }), 201
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/instances/<int:iid>/stop', methods=['POST'])
@jwt_required
@admin_required
def stop_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id = ?", (iid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    aws_stop(row['aws_id'])
    db().execute("UPDATE instances SET status = 'stopped' WHERE id = ?", (iid,))
    db().commit()
    return jsonify({'message': 'Stopped'})

@app.route('/api/instances/<int:iid>/start', methods=['POST'])
@jwt_required
@admin_required
def start_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id = ?", (iid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    db().execute("UPDATE instances SET status = 'running' WHERE id = ?", (iid,))
    db().commit()
    return jsonify({'message': 'Started'})

@app.route('/api/instances/<int:iid>', methods=['DELETE'])
@jwt_required
@admin_required
def delete_instance(iid):
    row = db().execute("SELECT * FROM instances WHERE id = ?", (iid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    aws_terminate(row['aws_id'])
    db().execute("DELETE FROM instance_data WHERE instance_id = ?", (iid,))
    db().execute("DELETE FROM users WHERE instance_id = ?",         (iid,))
    db().execute("DELETE FROM instances WHERE id = ?",              (iid,))
    db().commit()
    return jsonify({'message': 'Deleted'})

# ── Users ─────────────────────────────────────────────────────────
@app.route('/api/users', methods=['GET'])
@jwt_required
def get_users():
    u = current_user()
    if is_superadmin(u):
        rows = db().execute(
            "SELECT u.id, u.username, u.email, u.role, u.is_active, "
            "u.instance_id, u.created_at, u.plain_password, "
            "i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id = u.instance_id "
            "ORDER BY u.instance_id, u.id"
        ).fetchall()
    elif is_admin(u):
        rows = db().execute(
            "SELECT u.id, u.username, u.email, u.role, u.is_active, "
            "u.instance_id, u.created_at, u.plain_password, "
            "i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id = u.instance_id "
            "WHERE u.instance_id = ? ORDER BY u.id",
            (u['instance_id'],)
        ).fetchall()
    else:
        rows = db().execute(
            "SELECT u.id, u.username, u.email, u.role, u.is_active, "
            "u.instance_id, u.created_at, '' AS plain_password, "
            "i.name AS instance_name "
            "FROM users u LEFT JOIN instances i ON i.id = u.instance_id "
            "WHERE u.instance_id = ? ORDER BY u.id",
            (u['instance_id'],)
        ).fetchall()
    return jsonify({'users': [row_to_dict(r) for r in rows]})

@app.route('/api/users', methods=['POST'])
@jwt_required
@admin_required
def create_user():
    try:
        u    = current_user()
        data = request.get_json() or {}
        for field in ('username', 'email', 'password', 'instance_id'):
            if not data.get(field):
                return jsonify({'error': field + ' is required'}), 400
        target_iid = int(data['instance_id'])
        if not is_superadmin(u) and target_iid != u['instance_id']:
            return jsonify({'error': 'Can only add users to your own instance'}), 403
        if not db().execute(
            "SELECT id FROM instances WHERE id = ?", (target_iid,)
        ).fetchone():
            return jsonify({'error': 'Instance not found'}), 404
        if db().execute(
            "SELECT id FROM users WHERE username = ?", (data['username'],)
        ).fetchone():
            return jsonify({'error': 'Username already exists'}), 409
        if db().execute(
            "SELECT id FROM users WHERE email = ?", (data['email'],)
        ).fetchone():
            return jsonify({'error': 'Email already exists'}), 409
        pwd = data['password']
        cur = db().execute(
            "INSERT INTO users (username, email, password_hash, plain_password, role, instance_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (data['username'], data['email'],
             generate_password_hash(pwd), pwd,
             data.get('role', 'user'), target_iid)
        )
        db().commit()
        log_action('CREATE_USER', 'SUCCESS',
                   user_id=u['id'], username=u['username'],
                   instance_id=target_iid,
                   details='New user: ' + data['username'])
        return jsonify({'message': 'User created', 'user_id': cur.lastrowid}), 201
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/users/<int:uid>', methods=['DELETE'])
@jwt_required
@admin_required
def delete_user(uid):
    u = current_user()
    if uid == u['id']:
        return jsonify({'error': 'Cannot delete yourself'}), 400
    row = db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    if not is_superadmin(u) and row['instance_id'] != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    db().execute("DELETE FROM users WHERE id = ?", (uid,))
    db().commit()
    return jsonify({'message': 'User deleted'})

@app.route('/api/users/<int:uid>/toggle', methods=['POST'])
@jwt_required
@admin_required
def toggle_user(uid):
    u   = current_user()
    row = db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    if not is_superadmin(u) and row['instance_id'] != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    new = 0 if row['is_active'] else 1
    db().execute("UPDATE users SET is_active = ? WHERE id = ?", (new, uid))
    db().commit()
    return jsonify({'is_active': new, 'message': 'enabled' if new else 'disabled'})

@app.route('/api/instances/<int:iid>/users')
@jwt_required
@admin_required
def get_instance_users(iid):
    u = current_user()
    if not is_superadmin(u) and iid != u['instance_id']:
        return jsonify({'error': 'Access denied'}), 403
    rows = db().execute(
        "SELECT id, username, role FROM users "
        "WHERE instance_id = ? AND is_active = 1 ORDER BY username",
        (iid,)
    ).fetchall()
    return jsonify({'users': [row_to_dict(r) for r in rows]})

# ── Data (Encrypted + S3) ─────────────────────────────────────────
@app.route('/api/data', methods=['GET'])
@jwt_required
def get_data():
    try:
        u   = current_user()
        uid = u['id']
        if is_admin(u):
            if is_superadmin(u):
                rows = db().execute(
                    "SELECT d.*, i.name AS instance_name, us.username AS creator "
                    "FROM instance_data d "
                    "LEFT JOIN instances i ON i.id = d.instance_id "
                    "LEFT JOIN users us ON us.id = d.created_by "
                    "ORDER BY d.created_at DESC"
                ).fetchall()
            else:
                rows = db().execute(
                    "SELECT d.*, i.name AS instance_name, us.username AS creator "
                    "FROM instance_data d "
                    "LEFT JOIN instances i ON i.id = d.instance_id "
                    "LEFT JOIN users us ON us.id = d.created_by "
                    "WHERE d.instance_id = ? ORDER BY d.created_at DESC",
                    (u['instance_id'],)
                ).fetchall()
            result = []
            for r in rows:
                rec              = row_to_dict(r)
                rec['can_view']   = True
                rec['can_delete'] = True
                rec['content']    = '[Encrypted] Click View to decrypt'
                result.append(rec)
        else:
            rows = db().execute(
                "SELECT d.*, i.name AS instance_name, us.username AS creator "
                "FROM instance_data d "
                "LEFT JOIN instances i ON i.id = d.instance_id "
                "LEFT JOIN users us ON us.id = d.created_by "
                "WHERE d.instance_id = ? ORDER BY d.created_at DESC",
                (u['instance_id'],)
            ).fetchall()
            result = []
            for r in rows:
                rec              = row_to_dict(r)
                is_owner         = (r['created_by'] == uid)
                rec['can_view']   = is_owner
                rec['can_delete'] = is_owner
                rec['content']    = ('[Encrypted] Click View to decrypt'
                                     if is_owner else '[Private] Only owner can view')
                result.append(rec)
        log_action('VIEW_DATA', 'SUCCESS',
                   user_id=u['id'], username=u['username'],
                   instance_id=u['instance_id'])
        return jsonify({'records': result})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/data/<int:did>', methods=['GET'])
@jwt_required
def view_record(did):
    """Fetch one record and decrypt its content."""
    try:
        u   = current_user()
        row = db().execute(
            "SELECT d.*, i.name AS instance_name, us.username AS creator "
            "FROM instance_data d "
            "LEFT JOIN instances i ON i.id = d.instance_id "
            "LEFT JOIN users us ON us.id = d.created_by "
            "WHERE d.id = ?", (did,)
        ).fetchone()
        if not row:
            return jsonify({'error': 'Record not found'}), 404
        # Tenant isolation check
        if not is_admin(u):
            if row['instance_id'] != u['instance_id']:
                log_action('VIEW_DATA', 'BLOCKED_CROSS_TENANT',
                           user_id=u['id'], username=u['username'],
                           details='Cross-tenant attempt id=' + str(did))
                return jsonify({'error': 'Access denied — wrong tenant'}), 403
            if row['created_by'] != u['id']:
                log_action('VIEW_DATA', 'BLOCKED',
                           user_id=u['id'], username=u['username'],
                           details='Not owner of record ' + str(did))
                return jsonify({'error': 'Access denied — not your record'}), 403
        elif not is_superadmin(u) and row['instance_id'] != u['instance_id']:
            return jsonify({'error': 'Access denied'}), 403

        rec = row_to_dict(row)

        # Decrypt content
        raw             = rec.get('content', '')
        enc_flag        = bool(rec.get('is_encrypted', 0)) and is_encrypted(raw)
        rec['content']       = decrypt(raw) if enc_flag else raw
        rec['was_encrypted'] = enc_flag

        # Fetch file from S3 if stored there
        if rec.get('s3_file_key'):
            fb = s3.get_file_b64(rec['s3_file_key'])
            if fb:
                rec['file_data'] = fb

        log_action('VIEW_DECRYPT', 'SUCCESS',
                   user_id=u['id'], username=u['username'],
                   instance_id=row['instance_id'],
                   details='Decrypted record ' + str(did))
        return jsonify(rec)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': 'View error: ' + str(e)}), 500

@app.route('/api/data', methods=['POST'])
@jwt_required
def add_data():
    """Encrypt content and store in S3 + SQLite."""
    try:
        u    = current_user()
        data = request.get_json() or {}

        title   = (data.get('title') or '').strip()
        content = (data.get('content') or '').strip()
        if not title:
            return jsonify({'error': 'Title is required'}), 400
        if not content:
            return jsonify({'error': 'Content is required'}), 400

        iid = data.get('instance_id') or u['instance_id']
        if not iid:
            return jsonify({'error': 'No instance assigned to this user. Ask admin to fix.'}), 400
        iid = int(iid)

        if not is_admin(u) and iid != u['instance_id']:
            return jsonify({'error': 'Access denied'}), 403

        # Who owns this record
        assigned_to = data.get('assigned_user_id') or u['id']
        if not is_admin(u):
            assigned_to = u['id']

        # STEP 1 — Encrypt with AES-256-GCM
        enc_content = encrypt(content)
        print("[ENCRYPT] Record encrypted — title: " + title)

        file_name = data.get('file_name')
        file_data = data.get('file_data')
        file_type = data.get('file_type')

        # STEP 2 — Insert into SQLite (always — as reliable backup)
        cur = db().execute(
            "INSERT INTO instance_data "
            "(instance_id, title, content, is_encrypted, data_type, "
            "file_name, file_data, file_type, created_by) "
            "VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?)",
            (iid, title, enc_content,
             data.get('data_type', 'general'),
             file_name, None, file_type, assigned_to)
        )
        db().commit()
        rid = cur.lastrowid
        print("[DB] Record saved — id: " + str(rid))

        # STEP 3 — Upload encrypted record to S3 (primary storage)
        inst_row = db().execute(
            "SELECT name FROM instances WHERE id = ?", (iid,)
        ).fetchone()
        inst_name = inst_row['name'] if inst_row else ''

        s3_key = s3.put_record(rid, enc_content, {
            'instance_id':   iid,
            'instance_name': inst_name,
            'title':         title,
            'data_type':     data.get('data_type', 'general'),
            'created_by':    assigned_to,
            'username':      u['username'],
        })

        # STEP 4 — Handle file attachment
        s3_file_key = None
        if file_data:
            if s3.S3_ENABLED:
                s3_file_key = s3.put_file(rid, file_name or 'attachment',
                                          file_data, file_type or '')
                if not s3_file_key:
                    # S3 file upload failed — store in SQLite
                    db().execute(
                        "UPDATE instance_data SET file_data = ? WHERE id = ?",
                        (file_data, rid)
                    )
                    db().commit()
            else:
                # No S3 — store file in SQLite
                db().execute(
                    "UPDATE instance_data SET file_data = ? WHERE id = ?",
                    (file_data, rid)
                )
                db().commit()

        # STEP 5 — Save S3 keys to SQLite record
        db().execute(
            "UPDATE instance_data SET s3_key = ?, s3_file_key = ? WHERE id = ?",
            (s3_key, s3_file_key, rid)
        )
        db().commit()

        bucket   = os.environ.get('S3_BUCKET', '')
        s3_path  = ('s3://' + bucket + '/' + s3_key) if s3_key else 'SQLite only'
        print("[STORE] Record " + str(rid) + " stored at: " + s3_path)

        log_action('ADD_DATA', 'SUCCESS',
                   user_id=u['id'], username=u['username'],
                   instance_id=iid,
                   details='title=' + title + ' id=' + str(rid) + ' s3=' + str(bool(s3_key)))

        return jsonify({
            'message':  'Data saved — encrypted with AES-256-GCM',
            'id':        rid,
            'encrypted': True,
            'algorithm': 'AES-256-GCM',
            's3_stored': bool(s3_key),
            's3_key':    s3_key,
            's3_path':   s3_path,
        }), 201

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': 'Failed to save data: ' + str(e)}), 500

@app.route('/api/data/<int:did>', methods=['DELETE'])
@jwt_required
def delete_data(did):
    try:
        u   = current_user()
        row = db().execute(
            "SELECT * FROM instance_data WHERE id = ?", (did,)
        ).fetchone()
        if not row:
            return jsonify({'error': 'Not found'}), 404
        if is_admin(u):
            if not is_superadmin(u) and row['instance_id'] != u['instance_id']:
                return jsonify({'error': 'Access denied'}), 403
        else:
            if row['instance_id'] != u['instance_id']:
                return jsonify({'error': 'Access denied'}), 403
            if row['created_by'] != u['id']:
                log_action('DELETE_DATA', 'BLOCKED',
                           user_id=u['id'], username=u['username'],
                           details='Not owner of record ' + str(did))
                return jsonify({'error': 'Access denied — not your record'}), 403
        # Delete from S3
        s3.delete_record(did)
        db().execute("DELETE FROM instance_data WHERE id = ?", (did,))
        db().commit()
        log_action('DELETE_DATA', 'SUCCESS',
                   user_id=u['id'], username=u['username'],
                   instance_id=row['instance_id'])
        return jsonify({'message': 'Record deleted'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ── Stats ─────────────────────────────────────────────────────────
@app.route('/api/stats')
@jwt_required
@admin_required
def get_stats():
    try:
        u  = current_user()
        c  = db()
        s3info = s3.get_status()
        if is_superadmin(u):
            return jsonify({
                'instances': c.execute("SELECT COUNT(*) FROM instances").fetchone()[0],
                'users':     c.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                'data':      c.execute("SELECT COUNT(*) FROM instance_data").fetchone()[0],
                'logs':      c.execute("SELECT COUNT(*) FROM activity_logs").fetchone()[0],
                'running':   c.execute("SELECT COUNT(*) FROM instances WHERE status='running'").fetchone()[0],
                'encrypted': c.execute("SELECT COUNT(*) FROM instance_data WHERE is_encrypted=1").fetchone()[0],
                'aws':       AWS_ENABLED,
                'region':    _region,
                's3_enabled': s3info['s3_enabled'],
                'bucket':    s3info['bucket'],
            })
        else:
            iid = u['instance_id']
            return jsonify({
                'instances': 1,
                'users':     c.execute("SELECT COUNT(*) FROM users WHERE instance_id=?", (iid,)).fetchone()[0],
                'data':      c.execute("SELECT COUNT(*) FROM instance_data WHERE instance_id=?", (iid,)).fetchone()[0],
                'logs':      c.execute("SELECT COUNT(*) FROM activity_logs WHERE instance_id=?", (iid,)).fetchone()[0],
                'running':   1,
                'encrypted': c.execute("SELECT COUNT(*) FROM instance_data WHERE instance_id=? AND is_encrypted=1", (iid,)).fetchone()[0],
                'aws':       AWS_ENABLED,
                'region':    _region,
                's3_enabled': s3info['s3_enabled'],
                'bucket':    s3info['bucket'],
            })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/logs')
@jwt_required
@admin_required
def get_logs():
    try:
        u = current_user()
        if is_superadmin(u):
            rows = db().execute(
                "SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 200"
            ).fetchall()
        else:
            rows = db().execute(
                "SELECT * FROM activity_logs WHERE instance_id = ? "
                "ORDER BY timestamp DESC LIMIT 200",
                (u['instance_id'],)
            ).fetchall()
        return jsonify({'logs': [row_to_dict(r) for r in rows]})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ── Live Security Metrics (7 Parameters) ─────────────────────────
@app.route('/api/metrics')
@jwt_required
@admin_required
def get_metrics():
    try:
        u  = current_user()
        c  = db()
        sf = '' if is_superadmin(u) else (' AND instance_id=' + str(u['instance_id']))

        def n(sql):
            return c.execute(sql).fetchone()[0] or 0

        # 1 — Access Control Accuracy
        valid_ok   = n("SELECT COUNT(*) FROM activity_logs WHERE action IN ('VIEW_DATA','VIEW_DECRYPT','ADD_DATA','DELETE_DATA') AND status='SUCCESS'" + sf)
        acc_acc    = round((valid_ok / valid_ok * 100) if valid_ok > 0 else 100, 2)

        # 2 — Unauthorized Prevention Rate
        blocked    = n("SELECT COUNT(*) FROM activity_logs WHERE status LIKE 'BLOCKED%'" + sf)
        unauth     = n("SELECT COUNT(*) FROM activity_logs WHERE status LIKE 'BLOCKED%' OR (action='LOGIN' AND status='FAILED')" + sf)
        prev_rate  = round((blocked / unauth * 100) if unauth > 0 else 100, 2)

        # 3 — Data Leakage Rate
        cross      = n("SELECT COUNT(*) FROM activity_logs WHERE status='BLOCKED_CROSS_TENANT'" + sf)
        accesses   = n("SELECT COUNT(*) FROM activity_logs WHERE action='VIEW_DECRYPT'" + sf)
        leakage    = round((cross / accesses * 100) if accesses > 0 else 0, 4)

        # 4 — Tenant Isolation Enforcement
        total_rec  = n("SELECT COUNT(*) FROM instance_data")
        with_tid   = n("SELECT COUNT(*) FROM instance_data WHERE instance_id IS NOT NULL AND instance_id != 0")
        isolation  = round((with_tid / total_rec * 100) if total_rec > 0 else 100, 2)

        # 5 — Auth Success Rate
        login_ok   = n("SELECT COUNT(*) FROM activity_logs WHERE action='LOGIN' AND status='SUCCESS'" + sf)
        login_tot  = n("SELECT COUNT(*) FROM activity_logs WHERE action='LOGIN'" + sf)
        auth_rate  = round((login_ok / login_tot * 100) if login_tot > 0 else 100, 2)

        # 6 — Encryption Effectiveness
        enc_rec    = n("SELECT COUNT(*) FROM instance_data WHERE is_encrypted=1")
        all_rec    = n("SELECT COUNT(*) FROM instance_data")
        enc_pct    = round((enc_rec / all_rec * 100) if all_rec > 0 else 100, 2)

        # 7 — Average Response Time
        avg_row    = c.execute("SELECT AVG(response_ms) FROM activity_logs WHERE response_ms > 0" + sf).fetchone()
        avg_ms     = round(avg_row[0] if avg_row and avg_row[0] else 0, 1)

        # Recent events
        recent = c.execute(
            "SELECT timestamp, action, status, username, response_ms, details "
            "FROM activity_logs WHERE 1=1" + sf +
            " ORDER BY timestamp DESC LIMIT 25"
        ).fetchall()

        return jsonify({
            'metrics': [
                {
                    'no': 1, 'name': 'Access Control Accuracy',
                    'value': acc_acc, 'unit': '%', 'target': 'Close to 100%',
                    'status': 'good' if acc_acc >= 99 else 'warn',
                    'formula': '(Authorized OK / Total Valid) x 100',
                    'description': 'Authorized users accessing only their own data',
                },
                {
                    'no': 2, 'name': 'Unauthorized Access Prevention Rate',
                    'value': prev_rate, 'unit': '%', 'target': '100%',
                    'status': 'good' if prev_rate >= 100 else 'warn',
                    'formula': '(Blocked / Total Unauthorized) x 100',
                    'description': 'How effectively cross-tenant access is blocked',
                },
                {
                    'no': 3, 'name': 'Data Leakage Rate',
                    'value': leakage, 'unit': '%', 'target': '0%',
                    'status': 'good' if leakage == 0 else 'bad',
                    'formula': '(Leaked / Total Accessed) x 100',
                    'description': 'Tenant data exposed to another tenant',
                },
                {
                    'no': 4, 'name': 'Tenant Isolation Enforcement',
                    'value': isolation, 'unit': '%', 'target': '100%',
                    'status': 'good' if isolation >= 100 else 'warn',
                    'formula': '(Records with TenantID / Total) x 100',
                    'description': 'Every record has correct Tenant ID applied',
                },
                {
                    'no': 5, 'name': 'Authentication Success Rate',
                    'value': auth_rate, 'unit': '%', 'target': 'Above 95%',
                    'status': 'good' if auth_rate >= 95 else 'warn',
                    'formula': '(Successful Logins / Total Attempts) x 100',
                    'description': 'Legitimate users verified before access',
                },
                {
                    'no': 6, 'name': 'Data Encryption Effectiveness',
                    'value': enc_pct, 'unit': '%', 'target': '100%',
                    'status': 'good' if enc_pct >= 100 else 'warn',
                    'formula': '(Encrypted Records / Total Records) x 100',
                    'description': 'All data stored with AES-256-GCM encryption',
                },
                {
                    'no': 7, 'name': 'Average Response Time',
                    'value': avg_ms, 'unit': 'ms', 'target': 'Less than 200ms',
                    'status': 'good' if avg_ms < 200 else 'warn',
                    'formula': 'Total Response Time / Number of Requests',
                    'description': 'System performance while maintaining isolation',
                },
            ],
            'totals': {
                'all_records':       all_rec,
                'encrypted_records': enc_rec,
                'total_logins':      login_tot,
                'blocked_attempts':  blocked,
                'cross_tenant':      cross,
                'decryptions':       accesses,
                'total_api_calls':   n("SELECT COUNT(*) FROM activity_logs WHERE 1=1" + sf),
            },
            'recent_events': [
                {
                    'timestamp':   r[0], 'action':      r[1],
                    'status':      r[2], 'username':    r[3],
                    'response_ms': r[4], 'details':     r[5],
                }
                for r in recent
            ],
            's3_enabled':     s3.S3_ENABLED,
            'encryption_algo': 'AES-256-GCM',
            'generated_at':   datetime.utcnow().isoformat() + 'Z',
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ── Seed data ─────────────────────────────────────────────────────
def seed():
    conn = get_db()
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0:
        conn.close()
        return

    # superadmin
    conn.execute(
        "INSERT INTO users (username, email, password_hash, plain_password, role, instance_id) "
        "VALUES (?, ?, ?, ?, ?, NULL)",
        ('superadmin', 'superadmin@portal.com',
         generate_password_hash('Admin@1234'), 'Admin@1234', 'admin')
    )

    # 3 instances
    for iname, plan in [('Alpha Corp', 't2.micro'),
                        ('Beta Ltd',   't2.small'),
                        ('Gamma Inc',  't2.micro')]:
        conn.execute(
            "INSERT INTO instances (name, aws_id, status, ip_address, plan, source) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (iname, 'i-sim-' + iname.lower().replace(' ', ''),
             'running', '10.0.0.' + str(abs(hash(iname)) % 200 + 10),
             plan, 'portal')
        )
    conn.commit()

    def iid(name):
        return conn.execute(
            "SELECT id FROM instances WHERE name = ?", (name,)
        ).fetchone()['id']

    i1, i2, i3 = iid('Alpha Corp'), iid('Beta Ltd'), iid('Gamma Inc')

    users = [
        ('alpha_admin', 'alpha_admin@alpha.com', 'Alpha@1234', 'admin', i1),
        ('alice',       'alice@alpha.com',        'Alice@1234', 'user',  i1),
        ('john',        'john@alpha.com',          'John@1234',  'user',  i1),
        ('beta_admin',  'beta_admin@beta.com',     'Beta@1234',  'admin', i2),
        ('bob',         'bob@beta.com',             'Bob@1234',   'user',  i2),
        ('gamma_admin', 'gamma_admin@gamma.com',   'Gamma@1234', 'admin', i3),
        ('charlie',     'charlie@gamma.com',        'Charlie@1234','user', i3),
    ]
    for uname, email, pwd, role, inst_id in users:
        conn.execute(
            "INSERT INTO users (username, email, password_hash, plain_password, role, instance_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (uname, email, generate_password_hash(pwd), pwd, role, inst_id)
        )
    conn.commit()

    def uid(name):
        return conn.execute(
            "SELECT id FROM users WHERE username = ?", (name,)
        ).fetchone()['id']

    # Seed encrypted records
    sample = [
        (i1, 'Alpha Q1 Sales',    'Revenue $4.5M, Growth 12% — CONFIDENTIAL', 'financial', uid('alice')),
        (i1, 'Alpha HR Report',   '250 employees, payroll $2.1M — HR DATA',   'hr',        uid('alice')),
        (i1, 'John Project Plan', 'Q2 deadline, budget $500K — INTERNAL',     'general',   uid('john')),
        (i2, 'Beta Roadmap',      'Q2: v2.0 launch, Q3: AI features',         'product',   uid('bob')),
        (i2, 'Beta CRM Data',     'Nike, Adidas, Puma signed — CONFIDENTIAL', 'crm',       uid('bob')),
        (i3, 'Gamma Board Memo',  'Merger vote Q3 — BOARD CONFIDENTIAL',      'general',   uid('charlie')),
    ]
    for inst_id, title, content, dtype, created_by in sample:
        enc = encrypt(content)
        conn.execute(
            "INSERT INTO instance_data "
            "(instance_id, title, content, is_encrypted, data_type, created_by) "
            "VALUES (?, ?, ?, 1, ?, ?)",
            (inst_id, title, enc, dtype, created_by)
        )
    conn.commit()
    conn.close()

    print("")
    print("=" * 65)
    print("  AWS Cloud Portal V7 — Ready!")
    print("=" * 65)
    print("  superadmin   / Admin@1234  (Super Admin)")
    print("  alpha_admin  / Alpha@1234  (Alpha Corp Admin)")
    print("  alice        / Alice@1234  (Alpha Corp User)")
    print("  john         / John@1234   (Alpha Corp User)")
    print("  beta_admin   / Beta@1234   (Beta Ltd Admin)")
    print("  bob          / Bob@1234    (Beta Ltd User)")
    print("  gamma_admin  / Gamma@1234  (Gamma Inc Admin)")
    print("  charlie      / Charlie@1234(Gamma Inc User)")
    print("=" * 65)
    print("  Encryption : AES-256-GCM")
    s3info = s3.get_status()
    if s3info['s3_enabled']:
        print("  S3 Storage : ENABLED — " + str(s3info['bucket']))
    else:
        print("  S3 Storage : DISABLED (local SQLite only)")
    print("=" * 65)
    print("")


if __name__ == '__main__':
    init_schema()
    seed()
    app.run(debug=False, host='0.0.0.0', port=5000)
