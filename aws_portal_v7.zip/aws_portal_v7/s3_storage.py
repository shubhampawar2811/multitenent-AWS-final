"""
s3_storage.py — AWS S3 Storage
Python 3.9+ compatible (no | None type hints)
Stores AES-256-GCM encrypted records as JSON files in S3.
"""
import os
import json
import base64
from datetime import datetime

S3_BUCKET  = os.environ.get('S3_BUCKET', '')
S3_PREFIX  = os.environ.get('S3_PREFIX', 'portal-data/')
AWS_REGION = os.environ.get('AWS_REGION', 'ap-south-1')
AWS_KEY    = os.environ.get('AWS_ACCESS_KEY_ID', '')
AWS_SECRET = os.environ.get('AWS_SECRET_ACCESS_KEY', '')

_s3        = None
S3_ENABLED = False


def init_s3():
    global _s3, S3_ENABLED
    if not S3_BUCKET:
        print("[S3] S3_BUCKET not set — using local SQLite only")
        return
    try:
        import boto3
        kw = {'region_name': AWS_REGION}
        if AWS_KEY and AWS_SECRET:
            kw['aws_access_key_id']     = AWS_KEY
            kw['aws_secret_access_key'] = AWS_SECRET
        client = boto3.client('s3', **kw)
        client.head_bucket(Bucket=S3_BUCKET)
        _s3        = client
        S3_ENABLED = True
        print("[S3] Connected — bucket: " + S3_BUCKET)
        print("[S3] Prefix  — " + S3_PREFIX)
        print("[S3] Region  — " + AWS_REGION)
        print("[S3] All encrypted data will be stored in S3")
    except Exception as e:
        print("[S3] FAILED: " + str(e))
        print("[S3] Check your AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, S3_BUCKET, AWS_REGION")
        _s3        = None
        S3_ENABLED = False


init_s3()


def put_record(record_id, enc_content, meta):
    """
    Save encrypted record to S3.
    S3 path: {S3_PREFIX}records/{record_id}.json
    Returns S3 key string on success, None on failure.
    """
    if not S3_ENABLED or not _s3:
        return None
    key = S3_PREFIX + 'records/' + str(record_id) + '.json'
    body = json.dumps({
        'record_id':         record_id,
        'encrypted_content': enc_content,
        'algorithm':         'AES-256-GCM',
        'tenant_id':         str(meta.get('instance_id', '')),
        'instance_name':     str(meta.get('instance_name', '')),
        'title':             str(meta.get('title', '')),
        'data_type':         str(meta.get('data_type', 'general')),
        'created_by_user':   str(meta.get('username', '')),
        'stored_at':         datetime.utcnow().isoformat() + 'Z',
        'note':              'Content encrypted with AES-256-GCM. Unreadable without ENCRYPTION_KEY.'
    }, indent=2)
    try:
        _s3.put_object(
            Bucket      = S3_BUCKET,
            Key         = key,
            Body        = body.encode('utf-8'),
            ContentType = 'application/json',
            Metadata    = {
                'record-id':  str(record_id),
                'tenant-id':  str(meta.get('instance_id', '')),
                'encrypted':  'true',
                'algorithm':  'AES-256-GCM',
            }
        )
        print("[S3] Stored record " + str(record_id) + " -> " + key)
        return key
    except Exception as e:
        print("[S3] put_record FAILED: " + str(e))
        return None


def get_record(record_id):
    """
    Fetch encrypted record from S3.
    Returns dict with 'encrypted_content', or None.
    """
    if not S3_ENABLED or not _s3:
        return None
    key = S3_PREFIX + 'records/' + str(record_id) + '.json'
    try:
        resp = _s3.get_object(Bucket=S3_BUCKET, Key=key)
        return json.loads(resp['Body'].read().decode('utf-8'))
    except Exception as e:
        print("[S3] get_record " + str(record_id) + " FAILED: " + str(e))
        return None


def delete_record(record_id):
    """Delete a record from S3. Returns True on success."""
    if not S3_ENABLED or not _s3:
        return False
    key = S3_PREFIX + 'records/' + str(record_id) + '.json'
    try:
        _s3.delete_object(Bucket=S3_BUCKET, Key=key)
        print("[S3] Deleted record " + str(record_id))
        return True
    except Exception as e:
        print("[S3] delete_record FAILED: " + str(e))
        return False


def put_file(record_id, fname, data_b64, ftype):
    """
    Upload file attachment to S3.
    S3 path: {S3_PREFIX}files/{record_id}/{fname}
    Returns S3 key on success, None on failure.
    """
    if not S3_ENABLED or not _s3:
        return None
    fname = fname or 'attachment'
    key   = S3_PREFIX + 'files/' + str(record_id) + '/' + fname
    try:
        binary = base64.b64decode(data_b64)
        _s3.put_object(
            Bucket      = S3_BUCKET,
            Key         = key,
            Body        = binary,
            ContentType = ftype or 'application/octet-stream',
            Metadata    = {'record-id': str(record_id)}
        )
        print("[S3] Stored file for record " + str(record_id) + " -> " + key)
        return key
    except Exception as e:
        print("[S3] put_file FAILED: " + str(e))
        return None


def get_file_b64(s3_key):
    """Fetch file from S3, return as base64 string."""
    if not S3_ENABLED or not _s3 or not s3_key:
        return None
    try:
        resp = _s3.get_object(Bucket=S3_BUCKET, Key=s3_key)
        return base64.b64encode(resp['Body'].read()).decode()
    except Exception as e:
        print("[S3] get_file FAILED: " + str(e))
        return None


def get_status():
    """Return S3 connection status as a plain dict."""
    return {
        's3_enabled': S3_ENABLED,
        'bucket':     S3_BUCKET if S3_ENABLED else '',
        'prefix':     S3_PREFIX,
        'region':     AWS_REGION,
    }
