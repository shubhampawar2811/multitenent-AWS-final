"""
encryption.py — AES-256-GCM Encryption
Python 3.9+ compatible (no | None type hints)
"""
import os
import base64
import json
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

_RAW_KEY = os.environ.get('ENCRYPTION_KEY', 'DefaultKey-ChangeThis-InProduction!!')

def _derive_key(raw):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b'aws_portal_v7_salt_2024',
        iterations=100000,
    )
    return kdf.derive(raw.encode('utf-8'))

_KEY = _derive_key(_RAW_KEY)


def encrypt(plaintext):
    """Encrypt a string with AES-256-GCM. Returns base64 encoded ciphertext."""
    try:
        aesgcm = AESGCM(_KEY)
        nonce  = os.urandom(12)
        ct     = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
        blob   = {
            'n': base64.b64encode(nonce).decode(),
            'c': base64.b64encode(ct).decode(),
            'v': 'AES256GCMv1'
        }
        return base64.b64encode(json.dumps(blob).encode()).decode()
    except Exception as e:
        raise RuntimeError("Encryption failed: " + str(e))


def decrypt(ciphertext):
    """Decrypt an AES-256-GCM ciphertext. Returns original plaintext."""
    try:
        blob  = json.loads(base64.b64decode(ciphertext).decode())
        nonce = base64.b64decode(blob['n'])
        ct    = base64.b64decode(blob['c'])
        return AESGCM(_KEY).decrypt(nonce, ct, None).decode('utf-8')
    except Exception as e:
        return '[Decryption Error: ' + str(e) + ']'


def is_encrypted(value):
    """Check if a value is encrypted by this module."""
    try:
        blob = json.loads(base64.b64decode(value).decode())
        return blob.get('v') == 'AES256GCMv1'
    except Exception:
        return False
