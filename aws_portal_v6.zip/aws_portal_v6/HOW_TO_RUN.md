# AWS Cloud Portal V6 — How to Run

## What's New in V6
- 🔐 **AES-256-GCM Encryption** — All data stored encrypted, decrypted only on View
- ☁️ **S3 Storage** — Records and files uploaded to AWS S3 (falls back to local DB)
- 📊 **Live Metrics Tab** — 7 real-time measurable parameters for multi-tenant isolation

---

## Step 1 — Install Python Dependencies

```bash
cd aws_portal_v6
pip install -r requirements.txt
```

**requirements.txt includes:**
- Flask, PyJWT, Werkzeug (web framework + auth)
- boto3 (AWS SDK for EC2 + S3)
- cryptography (AES-256-GCM encryption)

---

## Step 2 — Set Environment Variables

### Minimum (runs locally, no AWS needed):
```bash
# Windows (Command Prompt)
set JWT_SECRET=your-secret-key-here
set ENCRYPTION_KEY=MySecretEncryptionKey32Chars!!

# Windows (PowerShell)
$env:JWT_SECRET="your-secret-key-here"
$env:ENCRYPTION_KEY="MySecretEncryptionKey32Chars!!"

# Linux / Mac
export JWT_SECRET="your-secret-key-here"
export ENCRYPTION_KEY="MySecretEncryptionKey32Chars!!"
```

### With AWS EC2 + S3 (full cloud mode):
```bash
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="your-secret..."
export AWS_REGION="ap-south-1"
export S3_BUCKET="your-bucket-name"
export S3_PREFIX="portal-data/"
export JWT_SECRET="your-secret-key-here"
export ENCRYPTION_KEY="MySecretEncryptionKey32Chars!!"
```

> **Note:** If you skip `AWS_ACCESS_KEY_ID` / `S3_BUCKET`, the portal runs in
> **simulation mode** — EC2 instances are simulated and data is stored in local SQLite.
> All encryption still works fully in simulation mode.

---

## Step 3 — Run the App

```bash
python app.py
```

You should see:
```
✅  AWS Portal V6 — AES-256-GCM Encryption + S3 + Live Metrics
======================================================================
  superadmin       / Admin@1234   → Super Admin (full access)
  alpha_corp_admin / Alpha@1234   → Alpha Corp Admin
  alice            / Alice@1234   → Alpha Corp User
  ...
======================================================================
🔐 Encryption : AES-256-GCM (all data encrypted at rest)
☁️  S3 Storage : ENABLED — your-bucket / DISABLED (local SQLite fallback)
📊 Metrics    : GET /api/metrics  (admin only)
```

Open your browser: **http://localhost:5000**

---

## Step 4 — Login Credentials

| Username | Password | Role |
|---|---|---|
| `superadmin` | `Admin@1234` | Super Admin — full system access |
| `alpha_corp_admin` | `Alpha@1234` | Alpha Corp Admin |
| `alice` | `Alice@1234` | Alpha Corp User |
| `john` | `John@1234` | Alpha Corp User |
| `beta_ltd_admin` | `Beta@1234` | Beta Ltd Admin |
| `bob` | `Bob@1234` | Beta Ltd User |
| `gamma_inc_admin` | `Gamma@1234` | Gamma Inc Admin |
| `charlie` | `Charlie@1234` | Gamma Inc User |

---

## How Encryption Works

| Step | What Happens |
|---|---|
| User clicks **+ Add Data** | Types plain text content |
| Click **Encrypt & Save** | Server encrypts using AES-256-GCM, stores ciphertext |
| Database / S3 stores | `eyJuIjogIj...` (base64 ciphertext — unreadable) |
| User clicks **👁 View** | Server decrypts on-the-fly, returns plain text |
| Browser shows | Original readable content |

---

## How S3 Storage Works

When `S3_BUCKET` is set:
- Each data record → uploaded as `portal-data/records/{id}.json` (contains encrypted content)
- File attachments → uploaded as `portal-data/files/{id}/{filename}`
- On delete → S3 object is also removed

When `S3_BUCKET` is NOT set:
- All data stays in local `instance/portal.db` SQLite file
- All encryption still works

---

## Live Metrics Tab (Admin Only)

Go to **Admin Panel → 📊 Live Metrics tab**

| # | Parameter | Formula | Target |
|---|---|---|---|
| 1 | Access Control Accuracy | (Auth OK / Total Valid) × 100 | ≥ 99% |
| 2 | Unauthorized Prevention Rate | (Blocked / Total Unauthorized) × 100 | 100% |
| 3 | Data Leakage Rate | (Cross-Tenant / Total Access) × 100 | 0% |
| 4 | Tenant Isolation Enforcement | (Records with TenantID / Total) × 100 | 100% |
| 5 | Authentication Success Rate | (Successful Logins / Attempts) × 100 | ≥ 95% |
| 6 | Data Encryption Effectiveness | (Encrypted / Total Records) × 100 | 100% |
| 7 | Average Response Time | Avg response_ms from logs | < 200ms |

Metrics **auto-refresh every 10 seconds** from live activity logs.

---

## Project Structure

```
aws_portal_v6/
├── app.py              ← Main Flask app (API routes + logic)
├── encryption.py       ← AES-256-GCM encrypt/decrypt functions
├── s3_storage.py       ← AWS S3 upload/download helpers
├── database.py         ← SQLite schema + connection helper
├── requirements.txt    ← Python dependencies
├── HOW_TO_RUN.md       ← This file
├── instance/
│   └── portal.db       ← SQLite DB (auto-created on first run)
└── templates/
    ├── index.html      ← Landing page
    ├── login.html      ← Login page
    ├── dashboard.html  ← User dashboard (encrypt + decrypt UI)
    └── admin.html      ← Admin panel (instances/users/data/logs/metrics)
```

---

## API Reference (Key Endpoints)

| Method | URL | Description |
|---|---|---|
| POST | `/api/login` | Login, get JWT token |
| GET | `/api/data` | List records (encrypted previews) |
| POST | `/api/data` | Add record (auto-encrypted + S3) |
| GET | `/api/data/{id}` | View record (auto-decrypted) |
| DELETE | `/api/data/{id}` | Delete record (from DB + S3) |
| GET | `/api/metrics` | Live 7-parameter metrics (admin) |
| GET | `/api/stats` | System stats |
| GET | `/api/logs` | Activity logs |
| POST | `/api/aws/sync` | Sync EC2 instances |

