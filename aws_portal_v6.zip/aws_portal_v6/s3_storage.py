"""
S3 Storage Utility — AWS Cloud Portal V6
Stores encrypted records to S3. Falls back silently to DB if unconfigured.
"""
import os, json, base64
from datetime import datetime

S3_BUCKET  = os.environ.get('S3_BUCKET', '')
S3_PREFIX  = os.environ.get('S3_PREFIX', 'portal-data/')
AWS_REGION = os.environ.get('AWS_REGION', 'ap-south-1')
AWS_KEY    = os.environ.get('AWS_ACCESS_KEY_ID', '')
AWS_SECRET = os.environ.get('AWS_SECRET_ACCESS_KEY', '')

_s3 = None
S3_ENABLED = False

def _init():
    global _s3, S3_ENABLED
    if not S3_BUCKET:
        print("⚠️   S3: S3_BUCKET not set — using local DB for storage"); return
    try:
        import boto3
        kw = dict(region_name=AWS_REGION)
        if AWS_KEY and AWS_SECRET:
            kw['aws_access_key_id'] = AWS_KEY
            kw['aws_secret_access_key'] = AWS_SECRET
        _s3 = boto3.client('s3', **kw)
        _s3.head_bucket(Bucket=S3_BUCKET)
        S3_ENABLED = True
        print(f"✅  S3 Connected — bucket: {S3_BUCKET} / prefix: {S3_PREFIX}")
    except Exception as e:
        print(f"⚠️   S3 disabled: {e}"); _s3 = None; S3_ENABLED = False

_init()

def put_record(record_id: int, enc_content: str, meta: dict) -> str | None:
    if not S3_ENABLED: return None
    key  = f"{S3_PREFIX}records/{record_id}.json"
    body = json.dumps({'id': record_id, 'encrypted_content': enc_content,
                       'meta': meta, 'stored_at': datetime.utcnow().isoformat()+'Z',
                       'algorithm': 'AES-256-GCM'})
    try:
        _s3.put_object(Bucket=S3_BUCKET, Key=key, Body=body.encode(),
                       ContentType='application/json',
                       Metadata={'tenant-id': str(meta.get('instance_id','')),
                                 'encrypted': 'true', 'algo': 'AES-256-GCM'})
        return key
    except Exception as e:
        print(f"S3 put_record error: {e}"); return None

def get_record(record_id: int) -> dict | None:
    if not S3_ENABLED: return None
    key = f"{S3_PREFIX}records/{record_id}.json"
    try:
        r = _s3.get_object(Bucket=S3_BUCKET, Key=key)
        return json.loads(r['Body'].read().decode())
    except Exception as e:
        print(f"S3 get_record error: {e}"); return None

def delete_record(record_id: int) -> bool:
    if not S3_ENABLED: return False
    try:
        _s3.delete_object(Bucket=S3_BUCKET, Key=f"{S3_PREFIX}records/{record_id}.json")
        return True
    except Exception as e:
        print(f"S3 delete error: {e}"); return False

def put_file(record_id: int, fname: str, data_b64: str, ftype: str) -> str | None:
    if not S3_ENABLED: return None
    key = f"{S3_PREFIX}files/{record_id}/{fname}"
    try:
        _s3.put_object(Bucket=S3_BUCKET, Key=key, Body=base64.b64decode(data_b64),
                       ContentType=ftype or 'application/octet-stream',
                       Metadata={'record-id': str(record_id)})
        return key
    except Exception as e:
        print(f"S3 put_file error: {e}"); return None

def get_file_b64(key: str) -> str | None:
    if not S3_ENABLED or not key: return None
    try:
        r = _s3.get_object(Bucket=S3_BUCKET, Key=key)
        return base64.b64encode(r['Body'].read()).decode()
    except Exception as e:
        print(f"S3 get_file error: {e}"); return None

def status() -> dict:
    return {'s3_enabled': S3_ENABLED, 'bucket': S3_BUCKET if S3_ENABLED else None,
            'prefix': S3_PREFIX, 'region': AWS_REGION}
