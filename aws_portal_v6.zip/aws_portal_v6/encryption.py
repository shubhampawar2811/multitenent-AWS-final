"""
AES-256-GCM Encryption Utility — AWS Cloud Portal V6
All tenant data encrypted at rest. Decrypted only on authorized view.
"""
import os, base64, json
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

_RAW = os.environ.get('ENCRYPTION_KEY', 'AwsPortalV6-AES256-SecretKey#2024!')

def _derive(raw: str) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                     salt=b'aws_portal_v6_static_salt', iterations=100_000)
    return kdf.derive(raw.encode())

_KEY = _derive(_RAW)

def encrypt(plaintext: str) -> str:
    aesgcm = AESGCM(_KEY)
    nonce  = os.urandom(12)
    ct     = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
    blob   = {'n': base64.b64encode(nonce).decode(),
              'c': base64.b64encode(ct).decode(),
              'v': 'AES256GCMv1'}
    return base64.b64encode(json.dumps(blob).encode()).decode()

def decrypt(enc: str) -> str:
    try:
        blob   = json.loads(base64.b64decode(enc).decode())
        nonce  = base64.b64decode(blob['n'])
        ct     = base64.b64decode(blob['c'])
        return AESGCM(_KEY).decrypt(nonce, ct, None).decode('utf-8')
    except Exception as e:
        return f'[Decryption Error: {e}]'

def is_encrypted(val: str) -> bool:
    try:
        return json.loads(base64.b64decode(val).decode()).get('v') == 'AES256GCMv1'
    except:
        return False
